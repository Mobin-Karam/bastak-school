import { ChevronLeft, ChevronRight, Search } from "lucide-react";
import { NavLink } from "react-router-dom";
import { adminDestination, localizedMainNavigationForCapabilities } from "./admin-navigation";
import { useAuth } from "../../../features/auth";
import { rolePortalTitle } from "../../../shared/lib/role-ui";
import { useAdminShellCopy, useLocale } from "../../../shared/ui/locale";

export function AdminMainSidebar({
  collapsed,
  currentSection,
  currentPath,
  selectedStudentId,
  onToggle,
  onOpenSearch,
  direction,
}: {
  collapsed: boolean;
  currentSection: string;
  currentPath: string;
  selectedStudentId: string;
  onToggle: () => void;
  onOpenSearch: () => void;
  direction: "rtl" | "ltr";
}) {
  const auth = useAuth();
  const { language } = useLocale();
  const copy = useAdminShellCopy();
  const visibleMainNavigation = localizedMainNavigationForCapabilities(
    auth.capabilities,
    auth.activeRole,
    language,
  );
  return (
    <aside
      className={`fixed inset-y-0 start-0 z-50 hidden flex-col border-e border-[rgb(var(--border-subtle))] bg-[rgb(var(--surface-card))] transition-[width,padding] duration-200 motion-reduce:transition-none lg:flex ${direction === "rtl" ? "shadow-[-1px_0_0_rgb(24_24_27_/_2%)]" : "shadow-[1px_0_0_rgb(24_24_27_/_2%)]"} ${collapsed ? "w-[4.25rem] p-2" : "w-60 p-3"}`}
      aria-label={copy.primaryNavigation}
    >
      <div
        className={`shrink-0 ${collapsed ? "mb-2 grid justify-items-center gap-1" : "mb-3 flex h-12 items-center justify-between gap-2 px-1"}`}
      >
        {!collapsed ? (
          <div className="min-w-0">
            <h1 className="truncate text-lg font-black tracking-tight">{copy.appTitle}</h1>
            <p className="truncate text-[11px] font-semibold text-slate-400">
              {rolePortalTitle(auth.activeRole, language)}
            </p>
          </div>
        ) : (
          <div
            className="grid size-8 place-items-center rounded-lg bg-brand text-sm font-black text-white"
            aria-hidden="true"
          >
            M
          </div>
        )}
        <button
          type="button"
          className="grid size-9 shrink-0 place-items-center rounded-lg text-slate-500 outline-none transition hover:bg-slate-100 focus-visible:ring-2 focus-visible:ring-brand"
          title={collapsed ? copy.openMainRail : copy.closeMainRail}
          aria-label={collapsed ? copy.openMainRail : copy.closeMainRail}
          aria-expanded={!collapsed}
          onClick={onToggle}
        >
          {collapsed === (direction === "rtl") ? (
            <ChevronLeft size={18} />
          ) : (
            <ChevronRight size={18} />
          )}
        </button>
      </div>

      <button
        type="button"
        className={`mb-3 flex h-9 w-full shrink-0 items-center rounded-md border border-[rgb(var(--border-subtle))] bg-[rgb(var(--surface-muted))] text-slate-500 outline-none transition hover:bg-[rgb(var(--surface-card))] focus-visible:ring-2 focus-visible:ring-brand ${collapsed ? "justify-center px-2" : "gap-2 px-3"}`}
        onClick={onOpenSearch}
        title={collapsed ? copy.searchAndGo : undefined}
        aria-label={copy.searchAndGo}
      >
        <Search size={17} className="shrink-0" />
        {!collapsed ? (
          <>
            <span className="min-w-0 flex-1 truncate text-start text-xs font-semibold">
              {copy.searchAndGo}
            </span>
            <kbd
              className="rounded border border-slate-200 bg-white px-1.5 py-0.5 text-[9px] font-bold text-slate-400"
              dir="ltr"
            >
              Ctrl ⇧ P
            </kbd>
          </>
        ) : null}
      </button>

      <nav className="grid min-h-0 flex-1 content-start gap-1 overflow-y-auto overscroll-contain pb-2">
        {visibleMainNavigation.map(({ path, title, section, icon: Icon }) => {
          const active = currentSection === section;
          return (
            <NavLink
              key={path}
              to={adminDestination(active ? currentPath : path, section, selectedStudentId)}
              end={path === ""}
              title={collapsed ? title : undefined}
              aria-label={title}
              aria-current={active ? "location" : undefined}
              className={`relative flex h-10 items-center rounded-md text-sm font-medium outline-none transition focus-visible:ring-2 focus-visible:ring-brand ${collapsed ? "justify-center px-2" : "gap-3 px-3"} ${active ? "bg-brand/10 text-brand" : "text-slate-600 hover:bg-[rgb(var(--surface-muted))] hover:text-ink"}`}
            >
              {active ? (
                <span
                  className="absolute inset-y-2 start-0 w-0.5 rounded-e-full bg-brand"
                  aria-hidden="true"
                />
              ) : null}
              <Icon className="shrink-0" size={19} strokeWidth={active ? 2.4 : 1.9} />
              {!collapsed ? <span className="truncate">{title}</span> : null}
            </NavLink>
          );
        })}
      </nav>
    </aside>
  );
}
