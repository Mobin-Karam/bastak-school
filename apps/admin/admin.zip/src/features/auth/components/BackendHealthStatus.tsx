import { CheckCircle2, RefreshCw, WifiOff } from "lucide-react";
import { useBackendHealth } from "../hooks/useBackendHealth";
import { useAuthLocale } from "../model/auth-locale";

export function BackendHealthStatus() {
  const { health, checkHealth } = useBackendHealth();
  const { copy } = useAuthLocale();

  return (
    <div
      className={[
        "mb-5 flex items-center gap-2.5 rounded-xl border px-3.5 py-3 text-xs",
        health.error
          ? "border-rose-200 bg-rose-50 text-rose-800"
          : "border-emerald-200 bg-emerald-50 text-emerald-800",
      ].join(" ")}
    >
      {health.loading ? (
        <RefreshCw className="animate-spin" size={16} />
      ) : health.error ? (
        <WifiOff size={16} />
      ) : (
        <CheckCircle2 size={16} />
      )}

      <span className="min-w-0 flex-1 truncate">
        {health.loading
          ? copy.connectionChecking
          : health.error
            ? copy.connectionUnavailable
            : copy.connectionReady(health.data?.version || "—")}
      </span>

      <button
        type="button"
        className="grid size-8 place-items-center rounded-lg transition hover:bg-black/5 focus-visible:ring-2 focus-visible:ring-current"
        aria-label={copy.retryConnection}
        onClick={() => void checkHealth()}
      >
        <RefreshCw size={15} />
      </button>
    </div>
  );
}
