export { ExamsPage } from "../exams";
