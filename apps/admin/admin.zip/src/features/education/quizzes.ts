export { QuizzesPage } from "../quizzes";
