export { ResourcesPage } from "../resources";
