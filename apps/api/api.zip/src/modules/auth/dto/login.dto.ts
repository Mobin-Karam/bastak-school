import { IsString, MaxLength, MinLength } from "class-validator";

export class LoginDto {
  @IsString()
  @MinLength(1)
  @MaxLength(120)
  phoneNumber!: string;

  @IsString()
  @MinLength(1)
  @MaxLength(300)
  password!: string;
}
