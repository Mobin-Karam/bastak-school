import {
  Body,
  Controller,
  Delete,
  Get,
  Param,
  Patch,
  Post,
  Put,
  Query,
} from "@nestjs/common";
import { CurrentUser } from "../../common/decorators/current-user.decorator";
import { Roles } from "../../common/decorators/roles.decorator";
import { ok } from "../../common/utils/envelope";
import { UserRole } from "../../database/entities/user.entity";
import { AuthenticatedUser } from "../auth";
import {
  AssignExamDto,
  ExamAudienceRulesDto,
  ExamClassAssignmentsDto,
  CreateExamDto,
  CreateQuestionDto,
  UpdateExamDto,
} from "./dto/create-exam.dto";
import { ExamsService } from "./exams.service";
import { ExamHeartbeatDto, SubmitExamDto } from "./dto/submit-exam.dto";
import { RequireCapabilities } from "../../common/decorators/capabilities.decorator";
import { AuthorizationService, UserContext } from "../authorization";
import { ApiException } from "../../common/exceptions/api.exception";

@Controller()
export class ExamsController {
  constructor(
    private readonly exams: ExamsService,
    private readonly authorization: AuthorizationService,
  ) {}

  private context(user: AuthenticatedUser): UserContext {
    return {
      ...user,
      roles: user.roles ?? [user.role],
      capabilities: user.capabilities ?? [],
      membershipIds: user.membershipIds ?? [],
      organizationIds: user.organizationIds ?? [],
    };
  }

  @Get("exams")
  @RequireCapabilities("exams.read")
  listCanonical(@CurrentUser() user: AuthenticatedUser) {
    const context = this.context(user);
    return this.exams
      .listScoped(
        context.organizationIds,
        context.roles.includes("PLATFORM_ADMIN"),
      )
      .then(ok);
  }

  @Post("exams")
  @RequireCapabilities("exams.create")
  async createCanonical(
    @CurrentUser() user: AuthenticatedUser,
    @Body() dto: CreateExamDto,
  ) {
    const context = this.context(user);
    const organizationId =
      dto.organizationId ??
      (context.organizationIds.length === 1
        ? context.organizationIds[0]
        : undefined);
    if (
      !context.roles.includes("PLATFORM_ADMIN") &&
      (!organizationId ||
        !this.authorization.canAccessOrganization(
          context,
          organizationId,
          "exams.create",
        ))
    )
      throw new ApiException(
        403,
        "ORGANIZATION_FORBIDDEN",
        "به این سازمان دسترسی ندارید.",
      );
    if (
      dto.studentId &&
      !(await this.authorization.canAccessStudent(
        context,
        dto.studentId,
        "exams.assign",
      ))
    )
      throw new ApiException(
        403,
        "STUDENT_FORBIDDEN",
        "به این دانش‌آموز دسترسی ندارید.",
      );
    const exam = await this.exams.create({ ...dto, organizationId }, user.id);
    if (dto.studentId)
      await this.exams.assign(exam.id, [dto.studentId], user.id);
    return ok(exam);
  }

  @Patch("exams/:id")
  @RequireCapabilities("exams.update")
  async updateCanonical(
    @CurrentUser() user: AuthenticatedUser,
    @Param("id") id: string,
    @Body() dto: UpdateExamDto,
  ) {
    await this.requireExamScope(user, id, "exams.update");
    return this.exams.update(id, { ...dto }).then(ok);
  }

  @Delete("exams/:id")
  @RequireCapabilities("exams.delete")
  async removeCanonical(
    @CurrentUser() user: AuthenticatedUser,
    @Param("id") id: string,
  ) {
    await this.requireExamScope(user, id, "exams.delete");
    return this.exams.remove(id).then(ok);
  }

  @Get("exams/:id/questions")
  @RequireCapabilities("questions.read")
  async questionsCanonical(
    @CurrentUser() user: AuthenticatedUser,
    @Param("id") id: string,
  ) {
    await this.requireExamScope(user, id, "questions.read");
    return this.exams.questionsForExam(id).then(ok);
  }
  @Get("exams/:id/analytics")
  @RequireCapabilities("exams.read")
  async analytics(
    @CurrentUser() user: AuthenticatedUser,
    @Param("id") id: string,
  ) {
    await this.requireExamScope(user, id, "exams.read");
    return this.exams.analytics(id).then(ok);
  }
  @Get("question-bank/exams")
  @RequireCapabilities("questions.read")
  questionBankExams(@CurrentUser() user: AuthenticatedUser) {
    const context = this.context(user);
    return this.exams
      .listScoped(
        context.organizationIds,
        context.roles.includes("PLATFORM_ADMIN"),
      )
      .then(ok);
  }
  @Post("exams/:id/questions")
  @RequireCapabilities("questions.create")
  async addQuestionCanonical(
    @CurrentUser() user: AuthenticatedUser,
    @Param("id") id: string,
    @Body() dto: CreateQuestionDto,
  ) {
    await this.requireExamScope(user, id, "questions.create");
    return this.exams.addQuestion(id, dto).then(ok);
  }
  @Patch("questions/:id")
  @RequireCapabilities("questions.update")
  async updateQuestionCanonical(
    @CurrentUser() user: AuthenticatedUser,
    @Param("id") id: string,
    @Body() dto: CreateQuestionDto,
  ) {
    await this.requireExamScope(
      user,
      await this.exams.examIdForQuestion(id),
      "questions.update",
    );
    return this.exams.updateQuestion(id, { ...dto }).then(ok);
  }
  @Delete("exams/:examId/questions/:id")
  @RequireCapabilities("questions.delete")
  async deleteQuestionCanonical(
    @CurrentUser() user: AuthenticatedUser,
    @Param("examId") examId: string,
    @Param("id") id: string,
  ) {
    await this.requireExamScope(user, examId, "questions.delete");
    return this.exams.deleteQuestion(id, examId).then(ok);
  }

  @Post("exams/:id/assignments")
  @RequireCapabilities("exams.assign")
  async assign(
    @CurrentUser() user: AuthenticatedUser,
    @Param("id") id: string,
    @Body() dto: AssignExamDto,
  ) {
    await this.requireExamScope(user, id, "exams.assign");
    for (const studentId of dto.studentIds)
      if (
        !(await this.authorization.canAccessStudent(
          this.context(user),
          studentId,
          "exams.assign",
        ))
      )
        throw new ApiException(
          403,
          "STUDENT_FORBIDDEN",
          "به یکی از دانش‌آموزان دسترسی ندارید.",
        );
    return ok(await this.exams.assign(id, dto.studentIds, user.id));
  }

  @Get("exams/:id/assignments")
  @RequireCapabilities("exams.read")
  async assignments(
    @CurrentUser() user: AuthenticatedUser,
    @Param("id") id: string,
  ) {
    await this.requireExamScope(user, id, "exams.read");
    return ok(await this.exams.assignmentsForExam(id));
  }

  @Get("exams/:id/class-assignments")
  @RequireCapabilities("exams.read")
  async classAssignments(
    @CurrentUser() user: AuthenticatedUser,
    @Param("id") id: string,
  ) {
    await this.requireExamScope(user, id, "exams.read");
    return this.exams.listClassAssignments(id).then(ok);
  }

  @Put("exams/:id/class-assignments")
  @RequireCapabilities("exams.assign")
  async setClassAssignments(
    @CurrentUser() user: AuthenticatedUser,
    @Param("id") id: string,
    @Body() dto: ExamClassAssignmentsDto,
  ) {
    await this.requireExamScope(user, id, "exams.assign");
    return this.exams.setClassAssignments(id, dto.classIds).then(ok);
  }

  @Put("exams/:id/audience-rules")
  @RequireCapabilities("exams.assign")
  async setAudienceRules(
    @CurrentUser() user: AuthenticatedUser,
    @Param("id") id: string,
    @Body() dto: ExamAudienceRulesDto,
  ) {
    await this.requireExamScope(user, id, "exams.assign");
    return this.exams.setAudienceRules(id, dto).then(ok);
  }

  @Delete("exams/:id/assignments/:studentId")
  @RequireCapabilities("exams.assign")
  async unassign(
    @CurrentUser() user: AuthenticatedUser,
    @Param("id") id: string,
    @Param("studentId") studentId: string,
  ) {
    await this.requireExamScope(user, id, "exams.assign");
    if (
      !(await this.authorization.canAccessStudent(
        this.context(user),
        studentId,
        "exams.assign",
      ))
    )
      throw new ApiException(
        403,
        "STUDENT_FORBIDDEN",
        "به این دانش‌آموز دسترسی ندارید.",
      );
    return ok(await this.exams.unassign(id, studentId));
  }

  @Get("students/:studentId/exam-attempts")
  @RequireCapabilities("exams.read")
  async staffStudentAttempts(
    @CurrentUser() user: AuthenticatedUser,
    @Param("studentId") studentId: string,
  ) {
    await this.requireStudentScope(user, studentId, "exams.read");
    return this.exams.historyForStudent(studentId).then(ok);
  }

  @Get("students/:studentId/exam-attempts/:attemptId")
  @RequireCapabilities("exams.read")
  async staffStudentAttempt(
    @CurrentUser() user: AuthenticatedUser,
    @Param("studentId") studentId: string,
    @Param("attemptId") attemptId: string,
  ) {
    await this.requireStudentScope(user, studentId, "exams.read");
    return this.exams.attemptForStudent(studentId, attemptId).then(ok);
  }

  private async requireExamScope(
    user: AuthenticatedUser,
    id: string,
    capability: string,
  ) {
    const context = this.context(user);
    const organizationId = await this.exams.organizationIdForExam(id);
    if (context.roles.includes("PLATFORM_ADMIN")) return;
    if (
      !organizationId ||
      !this.authorization.canAccessOrganization(
        context,
        organizationId,
        capability,
      )
    )
      throw new ApiException(404, "NOT_FOUND", "آزمون یافت نشد.");
  }
  private async requireStudentScope(
    user: AuthenticatedUser,
    id: string,
    capability: string,
  ) {
    if (
      !(await this.authorization.canAccessStudent(
        this.context(user),
        id,
        capability,
      ))
    )
      throw new ApiException(404, "NOT_FOUND", "دانش‌آموز یافت نشد.");
  }

  @Get("student/exams")
  @Roles(UserRole.STUDENT)
  @RequireCapabilities("exams.read")
  listForStudent(@CurrentUser() user: AuthenticatedUser) {
    return this.exams.listForStudent(user.id).then(ok);
  }

  @Get("student/exams/attempts")
  @Roles(UserRole.STUDENT)
  @RequireCapabilities("exams.read")
  history(@CurrentUser() user: AuthenticatedUser) {
    return this.exams.history(user.id).then(ok);
  }

  @Get("student/exams/attempts/:id")
  @Roles(UserRole.STUDENT)
  @RequireCapabilities("exams.read")
  resultForStudent(
    @Param("id") id: string,
    @CurrentUser() user: AuthenticatedUser,
  ) {
    return this.exams.resultForStudent(id, user.id).then(ok);
  }

  @Get("student/exams/:id/progress")
  @Roles(UserRole.STUDENT)
  @RequireCapabilities("exams.read")
  progress(@Param("id") id: string, @CurrentUser() user: AuthenticatedUser) {
    return this.exams.progress(id, user.id).then(ok);
  }

  @Get("student/exams/:id")
  @Roles(UserRole.STUDENT)
  @RequireCapabilities("exams.read")
  detail(@Param("id") id: string, @CurrentUser() user: AuthenticatedUser) {
    return this.exams.detail(id, user.id).then(ok);
  }

  @Patch("student/exams/attempts/:id")
  @Roles(UserRole.STUDENT)
  @RequireCapabilities("exams.read")
  saveProgress(
    @Param("id") id: string,
    @Body() dto: SubmitExamDto,
    @CurrentUser() user: AuthenticatedUser,
  ) {
    return this.exams.saveProgress(id, dto.answers, user.id).then(ok);
  }

  @Post("student/exams/:id/start")
  @Roles(UserRole.STUDENT)
  @RequireCapabilities("exams.read")
  start(@Param("id") id: string, @CurrentUser() user: AuthenticatedUser) {
    return this.exams.start(id, user.id).then(ok);
  }

  @Post("student/exams/:id/submit")
  @Roles(UserRole.STUDENT)
  @RequireCapabilities("exams.read")
  submit(
    @Param("id") id: string,
    @Body() dto: SubmitExamDto,
    @CurrentUser() user: AuthenticatedUser,
  ) {
    return this.exams.submitExam(id, dto.answers, user.id).then(ok);
  }

  @Post("student/exams/:examId/attempts/:attemptId/heartbeat")
  @Roles(UserRole.STUDENT)
  @RequireCapabilities("exams.read")
  heartbeat(
    @Param("examId") examId: string,
    @Param("attemptId") attemptId: string,
    @Body() dto: ExamHeartbeatDto,
    @CurrentUser() user: AuthenticatedUser,
  ) {
    return this.exams
      .heartbeat(examId, attemptId, user.id, dto.currentSectionId)
      .then(ok);
  }

  @Post("admin/exams")
  @Roles(UserRole.ADMIN)
  create(@Body() dto: CreateExamDto) {
    return this.exams.create(dto).then(ok);
  }

  @Get("admin/exams")
  @Roles(UserRole.ADMIN)
  listForAdmin(@Query("studentId") _studentId?: string) {
    return this.exams.list().then(ok);
  }

  @Patch("admin/exams/:id")
  @Roles(UserRole.ADMIN)
  update(@Param("id") id: string, @Body() body: Record<string, unknown>) {
    return this.exams.update(id, body).then(ok);
  }

  @Delete("admin/exams/:id")
  @Roles(UserRole.ADMIN)
  remove(@Param("id") id: string) {
    return this.exams.remove(id).then(ok);
  }

  @Get("admin/exams/:id/questions")
  @Roles(UserRole.ADMIN)
  listQuestions(@Param("id") id: string) {
    return this.exams.questionsForExam(id).then(ok);
  }

  @Post("admin/exams/:id/questions")
  @Roles(UserRole.ADMIN)
  addQuestion(
    @Param("id") id: string,
    @Body()
    dto: CreateQuestionDto & { question?: string; correctOption?: string },
  ) {
    return this.exams.addQuestion(id, dto).then(ok);
  }

  @Patch("admin/questions/:id")
  @Roles(UserRole.ADMIN)
  updateQuestion(
    @Param("id") id: string,
    @Body() body: Record<string, unknown>,
  ) {
    return this.exams.updateQuestion(id, body).then(ok);
  }

  @Delete("admin/questions/:id")
  @Roles(UserRole.ADMIN)
  deleteQuestion(@Param("id") id: string) {
    return this.exams.deleteQuestion(id).then(ok);
  }

  @Delete("admin/exams/:examId/questions/:id")
  @Roles(UserRole.ADMIN)
  deleteExamQuestion(@Param("examId") examId: string, @Param("id") id: string) {
    return this.exams.deleteQuestion(id, examId).then(ok);
  }

  @Get("admin/students/:studentId/attempts")
  @Roles(UserRole.ADMIN)
  studentAttempts(@Param("studentId") studentId: string) {
    return this.exams.historyForStudent(studentId).then(ok);
  }

  @Get("admin/students/:studentId/attempts/:attemptId")
  @Roles(UserRole.ADMIN)
  studentAttempt(
    @Param("studentId") studentId: string,
    @Param("attemptId") attemptId: string,
  ) {
    return this.exams.attemptForStudent(studentId, attemptId).then(ok);
  }

  @Post("admin/questions/import")
  @Roles(UserRole.ADMIN)
  importQuestions(
    @Body() body: { examId: string; questions: CreateQuestionDto[] },
  ) {
    return this.exams.importQuestions(body.examId, body.questions).then(ok);
  }
}
