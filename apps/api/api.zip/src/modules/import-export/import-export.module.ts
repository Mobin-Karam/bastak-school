import { Module } from "@nestjs/common";
import { AuthorizationModule } from "../authorization/authorization.module";
import { ImportExportController } from "./import-export.controller";
import { ImportExportService } from "./import-export.service";
@Module({
  imports: [AuthorizationModule],
  controllers: [ImportExportController],
  providers: [ImportExportService],
})
export class ImportExportModule {}
