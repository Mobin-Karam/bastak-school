import { Injectable } from "@nestjs/common";
import { InjectRepository } from "@nestjs/typeorm";
import { Repository } from "typeorm";
import * as webPush from "web-push";
import { ApiException } from "../../common/exceptions/api.exception";
import { NotificationPreference } from "../../database/entities/notification-preference.entity";
import { PushSubscription } from "../../database/entities/push-subscription.entity";
import { User } from "../../database/entities/user.entity";

@Injectable()
export class PushService {
  readonly enabled: boolean;
  readonly publicKey: string;
  constructor(
    @InjectRepository(PushSubscription)
    private subscriptions: Repository<PushSubscription>,
    @InjectRepository(NotificationPreference)
    private preferences: Repository<NotificationPreference>,
    @InjectRepository(User) private users: Repository<User>,
  ) {
    this.publicKey = process.env.VAPID_PUBLIC_KEY || "";
    this.enabled = !!(
      this.publicKey &&
      process.env.VAPID_PRIVATE_KEY &&
      process.env.VAPID_SUBJECT
    );
    if (this.enabled)
      webPush.setVapidDetails(
        process.env.VAPID_SUBJECT!,
        this.publicKey,
        process.env.VAPID_PRIVATE_KEY!,
      );
  }
  config() {
    return {
      enabled: this.enabled,
      publicKey: this.publicKey,
      supported: this.enabled,
      vapidPublicKey: this.publicKey,
    };
  }
  async status(userId: string, endpoint?: string) {
    const [registered, preference, subscriptions] = await Promise.all([
      endpoint
        ? this.subscriptions.exist({
            where: { user: { id: userId }, endpoint },
          })
        : this.subscriptions.exist({ where: { user: { id: userId } } }),
      this.preferences.findOne({ where: { user: { id: userId } } }),
      this.subscriptions.find({
        where: { user: { id: userId } },
        order: { updatedAt: "DESC" },
        take: 20,
      }),
    ]);
    const categories = preference?.categories || {};
    return {
      serverConfigured: this.enabled,
      registered,
      preferences: {
        lessons: categories.lessons ?? true,
        messages: categories.messages ?? true,
        exams: categories.exams ?? true,
        announcements: categories.announcements ?? true,
      },
      devices: subscriptions.map((row) => ({
        id: row.id,
        userAgent: row.userAgent || "مرورگر ناشناس",
        failureCount: row.failureCount,
        lastSuccessAt: row.lastSuccessAt?.toISOString() || null,
        updatedAt: row.updatedAt.toISOString(),
        current: Boolean(endpoint && row.endpoint === endpoint),
      })),
    };
  }
  async subscribe(
    userId: string,
    body: { endpoint: string; keys: { p256dh: string; auth: string } },
    userAgent = "",
  ) {
    if (
      !body.endpoint?.startsWith("https://") ||
      !body.keys?.p256dh ||
      !body.keys?.auth
    )
      throw new ApiException(
        400,
        "INVALID_SUBSCRIPTION",
        "اشتراک اعلان معتبر نیست.",
      );
    const user = await this.users.findOneByOrFail({ id: userId });
    let row = await this.subscriptions.findOne({
      where: { endpoint: body.endpoint },
    });
    row ||= this.subscriptions.create({ endpoint: body.endpoint, user });
    Object.assign(row, {
      user,
      p256dh: body.keys.p256dh,
      auth: body.keys.auth,
      userAgent: userAgent.slice(0, 300),
      failureCount: 0,
    });
    return this.subscriptions.save(row);
  }
  async unsubscribe(userId: string, endpoint?: string) {
    const qb = this.subscriptions
      .createQueryBuilder()
      .delete()
      .where("userId=:userId", { userId });
    if (endpoint) qb.andWhere("endpoint=:endpoint", { endpoint });
    const result = await qb.execute();
    return { removed: result.affected || 0 };
  }
  async setPreferences(
    userId: string,
    input: {
      enabled?: boolean;
      categories?: Record<string, boolean>;
      [key: string]: unknown;
    },
  ) {
    const user = await this.users.findOneByOrFail({ id: userId });
    let row = await this.preferences.findOne({
      where: { user: { id: userId } },
    });
    row ||= this.preferences.create({ user, enabled: true, categories: {} });
    if (input.enabled !== undefined) row.enabled = input.enabled;
    const flat = Object.fromEntries(
      ["lessons", "messages", "exams", "announcements"]
        .filter((k) => typeof input[k] === "boolean")
        .map((k) => [k, input[k] as boolean]),
    );
    row.categories = {
      ...row.categories,
      ...flat,
      ...(input.categories || {}),
    };
    await this.preferences.save(row);
    return this.status(userId);
  }
  async sendToUser(
    userId: string,
    n: {
      id?: string;
      title: string;
      body: string;
      category?: string;
      type?: string;
      url?: string | null;
    },
  ) {
    if (!this.enabled) return { sent: 0, removed: 0 };
    const preference = await this.preferences.findOne({
      where: { user: { id: userId } },
    });
    const category = n.category || "general";
    if (
      preference &&
      (!preference.enabled || preference.categories[category] === false)
    )
      return { sent: 0, removed: 0 };
    const rows = await this.subscriptions.find({
      where: { user: { id: userId } },
    });
    let sent = 0,
      removed = 0;
    await Promise.all(
      rows.map(async (row) => {
        try {
          await webPush.sendNotification(
            {
              endpoint: row.endpoint,
              keys: { p256dh: row.p256dh, auth: row.auth },
            },
            JSON.stringify({
              notificationId: n.id,
              title: n.title,
              body: n.body,
              type: n.type || category,
              url: n.url || "/",
            }),
            { TTL: 300, urgency: n.type === "MESSAGE" ? "high" : "normal" },
          );
          row.failureCount = 0;
          row.lastSuccessAt = new Date();
          await this.subscriptions.save(row);
          sent++;
        } catch (error) {
          const status = Number(
            (error as { statusCode?: number }).statusCode || 0,
          );
          if (status === 404 || status === 410) {
            await this.subscriptions.delete(row.id);
            removed++;
          } else {
            row.failureCount++;
            await this.subscriptions.save(row);
          }
        }
      }),
    );
    return { sent, removed };
  }
}
