import { CAPABILITIES_KEY } from "../src/common/decorators/capabilities.decorator";
import { AssessmentsController } from "../src/modules/assessments/assessments.controller";
import { StudentController, StudentParityController } from "../src/modules/students/students.controller";
import { StudentAdministrationController } from "../src/modules/students/student-administration.controller";
import { ExamsController } from "../src/modules/exams/exams.controller";
import { SubjectsController } from "../src/modules/subjects/subjects.controller";

describe("student learning capability metadata", () => {
  it.each([
    ["student progress", StudentController, "progress", "learning.read"],
    ["student plans", StudentController, "plans", "plans.read"],
    ["student dashboard", StudentController, "dashboard", "plans.read"],
    ["student reviews", StudentController, "reviews", "learning.read"],
    ["student learning items", StudentController, "learningItems", "learning.read"],
    ["create learning item", StudentParityController, "createLearning", "learning.create"],
    ["update learning item", StudentParityController, "updateLearning", "learning.update"],
    ["delete learning item", StudentParityController, "deleteLearning", "learning.update"],
    ["review learning item", StudentParityController, "reviewLearning", "learning.review"],
    ["learning history", StudentParityController, "learningHistory", "learning.read"],
    ["staff learning review", StudentAdministrationController, "reviewLearning", "learning.review"],
    ["student exam list", ExamsController, "listForStudent", "exams.read"],
    ["student exam detail", ExamsController, "detail", "exams.read"],
    ["start student exam", ExamsController, "start", "exams.read"],
    ["submit student exam", ExamsController, "submit", "exams.read"],
    ["question bank exam selector", ExamsController, "questionBankExams", "questions.read"],
    ["student exam syllabus", AssessmentsController, "studentSyllabus", "exams.read"],
    ["student syllabus progress", AssessmentsController, "progress", "exams.read"],
    ["student retry requests", AssessmentsController, "studentRetries", "exams.read"],
    ["request another exam attempt", AssessmentsController, "retry", "exams.read"],
    ["subject catalog", SubjectsController, "list", "subjects.read"],
    ["subject export", SubjectsController, "export", "subjects.read"],
    ["create subject", SubjectsController, "create", "subjects.create"],
    ["subject import sample", SubjectsController, "sample", "subjects.create"],
    ["subject import preview", SubjectsController, "previewImport", "subjects.create"],
    ["subject import commit", SubjectsController, "commitImport", "subjects.create"],
    ["update subject", SubjectsController, "update", "subjects.update"],
    ["archive subject", SubjectsController, "archive", "subjects.archive"],
    ["student subject settings", SubjectsController, "forStudent", "studentSubjects.read"],
    ["configure student subject", SubjectsController, "configure", "studentSubjects.manage"],
  ] as const)("requires a capability for %s", (_label, controller, method, capability) => {
    const handler = controller.prototype[method as keyof typeof controller.prototype];
    expect(Reflect.getMetadata(CAPABILITIES_KEY, handler)).toEqual([capability]);
  });
});
